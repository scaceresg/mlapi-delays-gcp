from challenge.api import app

application = app